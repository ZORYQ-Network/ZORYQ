import { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { KyvoLogo } from '@/components/KyvoLogo';
import { Card, Pill, SectionTitle } from '@/components/Ui';
import { colors } from '@/theme/colors';
import { feed } from '@/data/mock';
import { useApp } from '@/context/AppContext';
import { useSpotify } from '@/context/SpotifyContext';
import { useLocale } from '@/context/LocaleContext';

export default function SocialScreen() {
  const [post, setPost] = useState('');
  const [posted, setPosted] = useState(false);
  const { addXp, streak } = useApp();
  const spotify = useSpotify();
  const { t } = useLocale();

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <KyvoLogo compact />
          <View style={styles.tabs}>
            <Text style={styles.tabActive}>{t('forYou')}</Text>
            <Text style={styles.tab}>{t('following')}</Text>
            <Text style={styles.tab}>{t('discover')}</Text>
          </View>
        </View>

        <Card style={styles.spotifyCard}>
          <View style={styles.spotifyCover}><Text style={styles.coverText}>✦</Text></View>
          <View style={{ flex: 1 }}>
            <View style={styles.nowRow}><Text style={styles.eyebrow}>{t('nowPlaying')}</Text><Text style={styles.spotifyText}>● Spotify</Text></View>
            <Text style={styles.track}>{spotify.connected ? spotify.track : 'Stellar Dreams'}</Text>
            <Text style={styles.artist}>{spotify.connected ? spotify.artist : 'Galactic Waves · demo'}</Text>
            <View style={styles.playerRow}><Text style={styles.playerIcon}>◀</Text><Text style={styles.pause}>Ⅱ</Text><Text style={styles.playerIcon}>▶</Text></View>
          </View>
          <Pressable onPress={spotify.connected ? spotify.disconnect : spotify.connect}>
            <Pill tone={spotify.connected ? 'green' : 'purple'}>{spotify.connected ? 'ON' : spotify.configured ? 'Conectar' : 'Setup'}</Pill>
          </Pressable>
        </Card>

        <Card>
          <View style={styles.composerTop}>
            <View style={styles.avatar}><Text style={styles.avatarText}>K</Text></View>
            <TextInput
              value={post}
              onChangeText={setPost}
              placeholder={t('shareThoughts')}
              placeholderTextColor="#777A8C"
              multiline
              style={styles.input}
            />
          </View>
          <View style={styles.composerBottom}>
            <Text style={styles.tools}>⌁  ▧  GIF  ≡</Text>
            <Pressable
              style={[styles.postButton, !post.trim() && { opacity: 0.45 }]}
              disabled={!post.trim()}
              onPress={() => {
                setPosted(true);
                setPost('');
                addXp(68, 'first-social-post');
              }}
            ><Text style={styles.postText}>{t('post')}</Text></Pressable>
          </View>
        </Card>

        <Card style={styles.xpBanner}>
          <View><Text style={styles.xpCircle}>XP</Text></View>
          <View style={{ flex: 1 }}>
            <Text style={styles.xpLabel}>{posted ? 'Post publicado!' : 'SocialFi recompensa atividade real'}</Text>
            <Text style={styles.xpValue}>{posted ? '+68 XP' : 'Ganhe XP com participação saudável'}</Text>
          </View>
          <View><Text style={styles.streakLabel}>STREAK</Text><Text style={styles.streak}>🔥 {streak}</Text></View>
        </Card>

        {feed.map((item) => (
          <Card key={item.id} style={styles.feedCard}>
            <View style={styles.postHeader}>
              <View style={styles.feedAvatar}><Text style={styles.avatarText}>{item.name[0]}</Text></View>
              <View style={{ flex: 1 }}>
                <Text style={styles.name}>{item.name} <Text style={styles.verified}>◆</Text></Text>
                <Text style={styles.handle}>{item.handle} · {item.time}</Text>
              </View>
              <Text style={styles.more}>•••</Text>
            </View>
            <Text style={styles.body}>{item.body}</Text>
            {item.token ? (
              <View style={styles.tokenCard}>
                <Text style={styles.tokenName}>≋ {item.token.symbol}</Text>
                <Text style={styles.spark}>▁▂▃▃▄▅▆</Text>
                <View><Text style={styles.price}>{item.token.price}</Text><Text style={styles.green}>{item.token.change}</Text></View>
              </View>
            ) : null}
            <View style={styles.reactions}>
              <Text style={styles.like}>♥ {item.likes}</Text>
              <Text style={styles.react}>◯ {item.comments}</Text>
              <Text style={styles.react}>⇄ {item.reposts}</Text>
              <Text style={styles.react}>⌑</Text>
            </View>
          </Card>
        ))}

        <Card>
          <SectionTitle title="TRENDING CREATORS" action={t('viewAll')} />
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
            {['AltcoinDaily', 'DeFi_Degen', 'Web3Queen', 'NodePilot'].map((name, i) => (
              <View key={name} style={styles.creator}>
                <View style={styles.creatorAvatar}><Text style={styles.avatarText}>{name[0]}</Text></View>
                <View><Text style={styles.creatorName}>{name}</Text><Text style={styles.handle}>@{name}</Text></View>
                <Text style={styles.plus}>+</Text>
              </View>
            ))}
          </ScrollView>
        </Card>
        <View style={{ height: 20 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: { padding: 16, gap: 14 },
  header: { gap: 16 },
  tabs: { flexDirection: 'row', gap: 22, alignItems: 'center' },
  tab: { color: colors.muted, fontSize: 13, fontWeight: '700' },
  tabActive: { color: colors.text, fontSize: 13, fontWeight: '900', borderBottomWidth: 2, borderBottomColor: colors.violet, paddingBottom: 7 },
  spotifyCard: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: '#0D0C15', borderColor: '#3F3653' },
  spotifyCover: { width: 76, height: 76, borderRadius: 16, backgroundColor: '#251238', alignItems: 'center', justifyContent: 'center' },
  coverText: { color: colors.violet, fontSize: 40 },
  nowRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  eyebrow: { color: colors.muted, fontSize: 9, letterSpacing: 1.2, fontWeight: '800' },
  spotifyText: { color: colors.spotify, fontSize: 10, fontWeight: '800' },
  track: { color: colors.text, fontSize: 17, fontWeight: '900', marginTop: 5 },
  artist: { color: colors.muted, fontSize: 11, marginTop: 3 },
  playerRow: { flexDirection: 'row', alignItems: 'center', gap: 18, marginTop: 10 },
  playerIcon: { color: colors.text, fontSize: 15 },
  pause: { color: colors.text, width: 30, height: 30, borderRadius: 15, backgroundColor: '#5B31A3', textAlign: 'center', textAlignVertical: 'center', lineHeight: 30, fontWeight: '900' },
  composerTop: { flexDirection: 'row', gap: 12 },
  avatar: { width: 42, height: 42, borderRadius: 21, backgroundColor: '#2D1743', borderWidth: 1, borderColor: '#7C3AED', alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: '#EDE1FF', fontWeight: '900' },
  input: { flex: 1, minHeight: 68, color: colors.text, fontSize: 15, textAlignVertical: 'top' },
  composerBottom: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 12 },
  tools: { color: colors.muted, letterSpacing: 7, fontSize: 12 },
  postButton: { backgroundColor: colors.purple, paddingHorizontal: 22, paddingVertical: 11, borderRadius: 14 },
  postText: { color: colors.text, fontWeight: '900' },
  xpBanner: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: '#11130C', borderColor: '#56641C' },
  xpCircle: { color: colors.lime, borderWidth: 1, borderColor: colors.lime, borderRadius: 999, width: 44, height: 44, lineHeight: 42, textAlign: 'center', fontWeight: '900' },
  xpLabel: { color: '#B1B5A5', fontSize: 10 },
  xpValue: { color: colors.lime, fontSize: 17, fontWeight: '900', marginTop: 2 },
  streakLabel: { color: colors.muted, fontSize: 9 },
  streak: { color: colors.orange, fontWeight: '900', marginTop: 4 },
  feedCard: { backgroundColor: '#0C0D13' },
  postHeader: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  feedAvatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#211332', borderWidth: 1, borderColor: '#6D3FB0', alignItems: 'center', justifyContent: 'center' },
  name: { color: colors.text, fontWeight: '900', fontSize: 14 },
  verified: { color: colors.cyan, fontSize: 10 },
  handle: { color: colors.muted, fontSize: 10, marginTop: 2 },
  more: { color: colors.muted, letterSpacing: 2 },
  body: { color: '#E7E7EF', fontSize: 14, lineHeight: 21, marginTop: 14 },
  tokenCard: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: '#0D1017', borderWidth: 1, borderColor: '#242838', borderRadius: 15, padding: 12, marginTop: 13 },
  tokenName: { color: colors.text, fontWeight: '900' },
  spark: { flex: 1, color: colors.green, letterSpacing: 1 },
  price: { color: colors.text, textAlign: 'right', fontWeight: '800' },
  green: { color: colors.green, fontSize: 10, textAlign: 'right', marginTop: 2 },
  reactions: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 16 },
  like: { color: '#FF55C5', fontWeight: '800' },
  react: { color: colors.muted },
  creator: { minWidth: 172, flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#0C0D14', borderWidth: 1, borderColor: '#262837', padding: 10, borderRadius: 15 },
  creatorAvatar: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#25163B', alignItems: 'center', justifyContent: 'center' },
  creatorName: { color: colors.text, fontWeight: '800', fontSize: 11 },
  plus: { color: colors.lime, borderWidth: 1, borderColor: colors.lime, width: 25, height: 25, borderRadius: 13, textAlign: 'center', lineHeight: 22, fontWeight: '900', marginLeft: 'auto' }
});
