import { useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { KyvoLogo } from '@/components/KyvoLogo';
import { Card, GlowButton, Pill } from '@/components/Ui';
import { colors } from '@/theme/colors';
import { getPreviewQuote, SwapQuote } from '@/services/swap';
import { useApp } from '@/context/AppContext';
import { useLocale } from '@/context/LocaleContext';

export default function SwapScreen() {
  const [amount, setAmount] = useState('1.2500');
  const [quote, setQuote] = useState<SwapQuote | null>(null);
  const [reviewed, setReviewed] = useState(false);
  const { addXp } = useApp();
  const { t } = useLocale();

  useEffect(() => {
    const id = setTimeout(() => getPreviewQuote(amount).then(setQuote), 200);
    return () => clearTimeout(id);
  }, [amount]);

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <KyvoLogo compact />
          <Text style={styles.title}>{t('swap')}</Text>
          <Pill tone="purple">◆ Ethereum⌄</Pill>
        </View>

        <Card style={styles.swapCard}>
          <Text style={styles.label}>{t('from')}</Text>
          <View style={styles.amountRow}>
            <View><Text style={styles.token}>◆ ETH⌄</Text><Text style={styles.sub}>Ethereum</Text></View>
            <View style={{ flex: 1, alignItems: 'flex-end' }}>
              <TextInput value={amount} onChangeText={setAmount} keyboardType="decimal-pad" style={styles.amountInput} />
              <Text style={styles.sub}>{t('balance')}: 2.8437 ETH · MAX</Text>
            </View>
          </View>
          <View style={styles.divider}><View style={styles.flip}><Text style={styles.flipText}>⇅</Text></View></View>
          <Text style={styles.label}>{t('to')}</Text>
          <View style={styles.amountRow}>
            <View><Text style={styles.token}>≋ SOL⌄</Text><Text style={styles.sub}>Solana</Text></View>
            <View style={{ flex: 1, alignItems: 'flex-end' }}>
              <Text style={styles.output}>{quote?.toAmount ?? '—'}</Text>
              <Text style={styles.sub}>{quote?.expectedUsd ?? t('searchRoute')}</Text>
            </View>
          </View>
          <View style={styles.routeLine}>
            <Text style={styles.route}>◉ Cross-chain via KYVO Route</Text>
            <Pill tone="green">{t('secure')}</Pill>
          </View>
        </Card>

        <Card>
          <Text style={styles.label}>{t('route')}</Text>
          <View style={styles.networkRow}>
            <View><Text style={styles.sub}>{t('origin')}</Text><Text style={styles.network}>◆ Ethereum</Text></View>
            <Text style={styles.arrow}>⟶</Text>
            <View><Text style={styles.sub}>{t('destination')}</Text><Text style={styles.network}>≋ Solana</Text></View>
          </View>
        </Card>

        <View style={styles.advanced}>
          <View style={styles.setting}><Text style={styles.sub}>Slippage</Text><Text style={styles.settingText}>0.50%⌄</Text></View>
          <View style={styles.setting}><Text style={styles.sub}>{t('speed')}</Text><Text style={styles.settingText}>{t('normal')}⌄</Text></View>
        </View>

        <Card style={styles.bestRoute}>
          <View style={styles.bestHead}><Text style={styles.bestTitle}>{t('bestRoute')}</Text><Pill tone="green">{t('lowRisk')}</Pill></View>
          <QuoteRow label={t('expectedOutput')} value={`${quote?.toAmount ?? '—'} SOL`} />
          <QuoteRow label={t('networkFee')} value={quote?.networkFee ?? '—'} />
          <QuoteRow label={t('kyvoFee')} value={quote?.kyvoFee ?? '—'} />
          <QuoteRow label={t('priceImpact')} value={quote?.priceImpact ?? '—'} green />
          <Text style={styles.disclaimer}>A taxa KYVO só deve ser ativada no backend quando a integração de integrador estiver configurada e visível antes da assinatura.</Text>
        </Card>

        <GlowButton
          title={reviewed ? t('swapReviewed') : t('reviewSwap')}
          lime
          onPress={() => {
            setReviewed(true);
            addXp(quote?.xp ?? 10, 'swap-preview');
          }}
        />
        <Text style={styles.xpHint}>ⓧ Você ganha ~{quote?.xp ?? 0} XP por esta ação quando o motor real estiver conectado.</Text>
        <View style={{ height: 20 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

function QuoteRow({ label, value, green }: { label: string; value: string; green?: boolean }) {
  return <View style={styles.quoteRow}><Text style={styles.quoteLabel}>{label}</Text><Text style={[styles.quoteValue, green && { color: colors.green }]}>{value}</Text></View>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: { padding: 16, gap: 14 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  title: { color: colors.text, fontSize: 23, fontWeight: '900' },
  swapCard: { backgroundColor: '#0B0B14', borderColor: '#46345F', padding: 18 },
  label: { color: '#989BAD', fontSize: 10, fontWeight: '800', letterSpacing: 1.5 },
  amountRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 14, paddingVertical: 14 },
  token: { color: colors.text, fontSize: 20, fontWeight: '900' },
  sub: { color: colors.muted, fontSize: 11, marginTop: 4 },
  amountInput: { color: colors.text, fontSize: 32, fontWeight: '900', minWidth: 150, textAlign: 'right', padding: 0 },
  output: { color: colors.text, fontSize: 32, fontWeight: '900' },
  divider: { height: 1, backgroundColor: '#31253F', marginVertical: 8, alignItems: 'center', justifyContent: 'center' },
  flip: { width: 42, height: 42, borderRadius: 21, backgroundColor: '#161125', borderWidth: 1, borderColor: '#8157C8', alignItems: 'center', justifyContent: 'center' },
  flipText: { color: colors.cyan, fontSize: 23, fontWeight: '900' },
  routeLine: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 10 },
  route: { color: '#B5A8C4', fontSize: 11 },
  networkRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 10 },
  network: { color: colors.text, fontWeight: '800', marginTop: 5 },
  arrow: { color: colors.cyan, fontSize: 26 },
  advanced: { flexDirection: 'row', gap: 10 },
  setting: { flex: 1, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.panel, borderRadius: 14, padding: 13 },
  settingText: { color: colors.text, fontWeight: '800', marginTop: 5 },
  bestRoute: { borderColor: '#543171', backgroundColor: '#0D0C15' },
  bestHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  bestTitle: { color: colors.text, fontSize: 13, fontWeight: '900', letterSpacing: 1 },
  quoteRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 9, borderBottomWidth: 1, borderBottomColor: '#1D1E2A' },
  quoteLabel: { color: colors.muted, fontSize: 12 },
  quoteValue: { color: colors.text, fontSize: 12, fontWeight: '800' },
  disclaimer: { color: '#747789', fontSize: 9, lineHeight: 14, marginTop: 12 },
  xpHint: { color: colors.lime, opacity: 0.8, fontSize: 10, textAlign: ''row', alignItems: },
  or: co