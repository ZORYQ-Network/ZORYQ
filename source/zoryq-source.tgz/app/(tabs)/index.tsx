import { router } from 'expo-router';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ZoryqLogo } from '@/components/ZoryqLogo';
import { Card, Pill, SectionTitle } from '@/components/Ui';
import { assets } from '@/data/mock';
import { colors } from '@/theme/colors';
import { useApp } from '@/context/AppContext';
import { useSpotify } from '@/context/SpotifyContext';
import { useLocale } from '@/context/LocaleContext';



export default function HomeScreen() {
  const { xp, level, streak } = useApp();
  const spotify = useSpotify();
  const { t, formatCurrency } = useLocale();

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <ZoryqLogo />
          <View style={styles.headerRight}>
            <Pressable onPress={() => router.push('/wallet')} style={styles.avatar}><Text style={styles.avatarText}>K</Text></Pressable>
            <Text style={styles.bell}>♢</Text>
          </View>
        </View>

        <Card style={styles.hero}>
          <View style={styles.heroTop}>
            <Text style={styles.eyebrow}>{t('portfolio')}</Text>
            <Pill tone="purple">USD⌄</Pill>
          </View>
          <Text style={styles.balance}>{formatCurrency(28730.68)}</Text>
          <Text style={styles.green}>▲ 8.47% <Text style={styles.muted}>(24H)</Text></Text>
          <View style={styles.graph}>
            {[20, 27, 24, 36, 32, 48, 43, 61, 57, 69, 75].map((h, i) => (
              <View key={i} style={[styles.graphBar, { height: h }]} />
            ))}
          </View>
        </Card>

        <View style={styles.actions}>{[['↗',t('send')],['↓',t('receive')],['⇄',t('swap')],['+',t('buy')]].map(([icon,label],i)=><Pressable key={label} onPress={()=>i===2?router.push('/swap'):router.push('/wallet')} style={styles.actionCard}><Text style={[styles.actionIcon,i===3&&{color:colors.lime}]}>{icon}</Text><Text style={styles.actionText}>{label}</Text></Pressable>)}</View>

        <Card>
          <SectionTitle title={t('myWallet')} action={t('viewAll')} />
          {assets.map((asset, idx) => (
            <View key={asset.symbol} style={[styles.assetRow, idx < assets.length - 1 && styles.assetBorder]}>
              <View style={[styles.tokenIcon, asset.symbol === 'BTC' && { backgroundColor: '#F7931A' }, asset.symbol === 'USDC' && { backgroundColor: '#2775CA' }]}>
                <Text style={styles.tokenIconText}>{asset.icon}</Text>
              </View>
              <View style={styles.assetMain}>
                <Text style={styles.assetSymbol}>{asset.symbol}</Text>
                <Text style={styles.assetName}>{asset.name}</Text>
              </View>
              <View style={styles.assetValue}>
                <Text style={styles.assetBalance}>{asset.balance}</Text>
                <Text style={styles.assetUsd}>{asset.value}</Text>
              </View>
              <Text style={styles.greenSmall}>▲ {asset.change.toFixed(2)}%</Text>
            </View>
          ))}
        </Card>

        <View style={styles.gridTwo}>
          <Card style={styles.halfCard}>
            <Text style={styles.eyebrow}>{t('multiChain')}</Text>
            <View style={styles.chainRow}>
              {['◆', '≋', '⬡', '◈', '+75'].map((x) => <View key={x} style={styles.chain}><Text style={styles.chainText}>{x}</Text></View>)}
            </View>
            <Text style={styles.cardTitle}>Wallet preparada para crescer</Text>
            <Text style={styles.body}>EVM, Solana, Bitcoin e novas redes por adaptadores.</Text>
          </Card>
          <Card style={[styles.halfCard, styles.xpCard]}>
            <Text style={styles.eyebrow}>NÍVEL {level}</Text>
            <Text style={styles.cardTitle}>Stellar Voyager</Text>
            <View style={styles.progress}><View style={[styles.progressFill, { width: `${Math.min(100, (xp % 8000) / 80)}%` }]} /></View>
            <Text style={styles.purple}>{xp.toLocaleString('pt-BR')} XP</Text>
            <Text style={styles.body}>🔥 streak de {streak} dias</Text>
          </Card>
        </View>

        <View style={styles.gridTwo}>
          <Pressable style={{flex:1}} onPress={() => router.push('/one')}><Card style={[styles.halfCard,{borderColor:'#5A37A0'}]}><Text style={styles.eyebrow}>ZORYQ ONE</Text><Text style={styles.cardTitle}>Diga o resultado. A ZORYQ planeja.</Text><Text style={styles.body}>Intent engine para rede, rota, custo, bridge e swap.</Text><Text style={[styles.purple,{marginTop:12}]}>Abrir →</Text></Card></Pressable>
          <Pressable style={{flex:1}} onPress={() => router.push('/guard')}><Card style={[styles.halfCard,{borderColor:'#176B61'}]}><Text style={styles.eyebrow}>ZORYQ GUARD</Text><Text style={styles.cardTitle}>Verifique antes de assinar.</Text><Text style={styles.body}>Score, simulação e alertas de approvals/contratos.</Text><Text style={{color:colors.lime,fontWeight:'800',fontSize:12,marginTop:12}}>Analisar →</Text></Card></Pressable>
        </View>

        <Card style={styles.airdrop}>
          <View style={{ flex: 1 }}>
            <Text style={styles.eyebrow}>{t('airdrop')}</Text>
            <Text style={styles.airdropTitle}>{t('comingSoon')}</Text>
            <Text style={styles.body}>{t('airdropHint')}</Text>
          </View>
          <Text style={styles.gift}>✦</Text>
        </Card>

        <Card>
          <SectionTitle title={t('spotify').toUpperCase()} action={spotify.connected ? t('connected') : t('integrate')} />
          <Pressable onPress={spotify.connected ? spotify.disconnect : spotify.connect}>
            <View style={styles.spotifyRow}>
              <View style={styles.spotifyIcon}><Text style={styles.spotifyIconText}>♫</Text></View>
              <View style={{ flex: 1 }}>
                <Text style={styles.assetSymbol}>{spotify.connected ? spotify.track : 'Spotify dentro da ZORYQ'}</Text>
                <Text style={styles.assetName}>{spotify.connected ? spotify.artist : spotify.configured ? 'Toque para conectar com PKCE' : 'Adicione o Client ID para ativar'}</Text>
              </View>
              <Pill tone="green">{spotify.connected ? 'ON' : 'OFF'}</Pill>
            </View>
          </Pressable>
        </Card>

        <View style={{ height: 20 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: { padding: 16, gap: 14 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 2 },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  avatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: '#28163B', borderWidth: 1, borderColor: '#7C3AED', alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: '#E6D8FF', fontWeight: '900' },
  bell: { color: colors.text, fontSize: 26 },
  hero: { backgroundColor: '#0D0D16', minHeight: 230, overflow: 'hidden', borderColor: '#40345B' },
  heroTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  eyebrow: { color: '#A3A5B4', fontSize: 11, fontWeight: '800', letterSpacing: 1.6 },
  balance: { color: colors.text, fontSize: 40, fontWeight: '900', letterSpacing: -1.2, marginTop: 18 },
  green: { color: colors.green, fontSize: 15, fontWeight: '800', marginTop: 4 },
  muted: { color: colors.muted, fontWeight: '500' },
  graph: { height: 80, flexDirection: 'row', gap: 5, alignItems: 'flex-end', marginTop: 18, paddingHorizontal: 4 },
  graphBar: { flex: 1, borderRadius: 8, backgroundColor: '#8B5CF6' },
  actions: { flexDirection: 'row', gap: 9 },
  actionCard: { flex: 1, minHeight: 92, borderWidth: 1, borderColor: colors.border, borderRadius: 18, backgroundColor: colors.panel, alignItems: 'center', justifyContent: 'center', gap: 7 },
  actionIcon: { color: colors.cyan, fontSize: 25, fontWeight: '900' },
  actionText: { color: colors.text, fontSize: 12, fontWeight: '700' },
  assetRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, gap: 10 },
  assetBorder: { borderBottomWidth: 1, borderBottomColor: '#202230' },
  tokenIcon: { width: 42, height: 42, borderRadius: 21, backgroundColor: '#2B4B9A', alignItems: 'center', justifyContent: 'center' },
  tokenIconText: { color: '#FFF', fontSize: 21, fontWeight: '900' },
  assetMain: { flex: 1 },
  assetSymbol: { color: colors.text, fontSize: 15, fontWeight: '800' },
  assetName: { color: colors.muted, fontSize: 12, marginTop: 2 },
  assetValue: { alignItems: 'flex-end' },
  assetBalance: { color: colors.text, fontSize: 13, fontWeight: '700' },
  assetUsd: { color: colors.muted, fontSize: 11, marginTop: 2 },
  greenSmall: { color: colors.green, fontSize: 10, fontWeight: '800', width: 58, textAlign: 'right' },
  gridTwo: { flexDirection: 'row', gap: 10 },
  halfCard: { flex: 1, minHeight: 150 },
  xpCard: { backgroundColor: '#140F20', borderColor: '#5C2B8C' },
  chainRow: { flexDirection: 'row', gap: 5, marginVertical: 11, flexWrap: 'wrap' },
  chain: { backgroundColor: '#171927', borderRadius: 999, minWidth: 28, height: 28, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 7 },
  chainText: { color: colors.text, fontSize: 11, fontWeight: '800' },
  cardTitle: { color: colors.text, fontSize: 14, fontWeight: '800', marginTop: 6 },
  body: { color: colors.muted, fontSize: 11, lineHeight: 16, marginTop: 5 },
  progress: { height: 7, backgroundColor: '#28243B', borderRadius: 99, overflow: 'hidden', marginVertical: 12 },
  progressFill: { height: '100%', backgroundColor: colors.violet, borderRadius: 99 },
  purple: { color: '#B891FF', fontWeight: '800', fontSize: 12 },
  airdrop: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#171027', borderColor: '#6C35AA' },
  airdropTitle: { color: '#DABEFF', fontSize: 27, fontWeight: '900', marginTop: 5 },
  gift: { color: colors.lime, fontSize: 62, paddingHorizontal: 14 },
  spotifyRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  spotifyIcon: { width: 46, height: 46, borderRadius: 23, backgroundColor: colors.spotify, alignItems: 'center', justifyContent: 'center' },
  spotifyIconText: { fontSize: 24, fontWeight: '900', color: '#06110A' }
});
